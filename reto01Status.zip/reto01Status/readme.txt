=== Reto 01: Plugin ===
Contributors: Jesús Landa
Tags: status worpress
Text Domain: reto01Status
Requires PHP: 7.2, 7.3

== Description ==

= Main Features =

= Data Privacy and GDPR Compliance =

== Installation ==

= Installing =

= Manual Instllation (Recommended) =

= Further Installation Details =

== Changelog ==

= 1.0 =
* First Release